declare module 'eslint-plugin-react-compiler' {
  import type { ESLint } from 'eslint'

  let plugin: ESLint.Plugin
  export default plugin
}
