export const BORDER_HEIGHT = 1
export const MULTI_DAY_EVENT_HEIGHT = 28
export const MONTH_NUMBER_HEIGHT = 27
export const MONTH_BAR_HEIGHT = 23
